package courswork;

import java.io.FileNotFoundException;// Import necessary libraries for file handling, user input, and arrays
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Arrays;

public class BookingSystem {

    private static Scanner input = new Scanner(System.in);// scanner for the user's input from the console 
    private static final Cottage[] cottages = new Cottage[18]; //array to store the 18 cottages we got

    //Data are loaded from the file 
    private static void loadCottages() throws FileNotFoundException {
        Scanner file = new Scanner(new FileReader("cottages (2).txt"));
        int index = 0;

        while (file.hasNextLine() && index < cottages.length) {
            String line = file.nextLine().trim();
            if (line.isEmpty()) continue;// skip any empty lines in the file 

            String[] parts = line.split("\\s+");// split the line by spaces 
            if (parts.length < 7) {
                // If line doesn't have 7 parts, skip it
                continue;
            }
// read all the information form the file 
            int id = Integer.parseInt(parts[0]);// int is used because the id is a number 
            String type = parts[1];// string for words 
            int bedrooms = Integer.parseInt(parts[2]);
            double price = Double.parseDouble(parts[3]);// price can be decimal
            boolean seaView = Boolean.parseBoolean(parts[4]);
            boolean pets = Boolean.parseBoolean(parts[5]);
            
            String bookedName = parts[6];
// create a new cottage for all of this informations
            cottages[index] = new Cottage(id, type, bedrooms, price, seaView, pets, bookedName);
            index++;// move to the next position in the array 
        }

        file.close();
    }

 
    private static void displayCottages() {
        System.out.println("ALL COTTAGES");
        boolean any = false;
        for (int i = 0; i < cottages.length; i++) {
            Cottage c = cottages[i];
            if (c == null) continue;        // skip empty slots
            System.out.println(c.toString());
            any = true;
        }
        if (!any) System.out.println("No cottages loaded.");
    }

 // shows only cottages that are booked
    private static void displayReservedCottages() {
        System.out.println("RESERVED COTTAGES");
        boolean found = false;

        for (Cottage c : cottages) {
            if (c == null) continue;           
            if (c.isBooked()) {
                System.out.println(c);
                found = true;
            }
        }

        if (!found) {
            System.out.println("There are no reserved cottages yet.");
        }
    }


    
    private static int readInt(String prompt) {// read and safe the input from the user 
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(input.nextLine().trim());
            } catch (Exception e) {
                System.out.println("Please enter a valid whole number."); // keeps looping until the user enters  valid number  
            }
        }
    }

    private static double readDouble(String prompt) {//read the user's input and safe them 
        while (true) {
            try {
                System.out.print(prompt);
                return Double.parseDouble(input.nextLine().trim());
            } catch (Exception e) {
                System.out.println("Sorry, please enter a valid number.");//a loop for error handling code 
            }
        }
    }

    private static String readString(String prompt) {// read string from the user and store it 
        System.out.print(prompt);
        return input.nextLine().trim();
    }

    private static boolean readYesNo(String prompt) {
        while (true) {//loop until valid input 
            System.out.print(prompt);// show the question to the user 
            String s = input.nextLine().trim().toLowerCase();// take the user's input, remove the spaces and convert it to lower case 
            if (s.equals("y") || s.equals("yes")) return true;
            if (s.equals("n") || s.equals("no")) return false;
            System.out.println("Try again, Please enter Y or N."); // for invalid input ask again 
        }
    }

    
    private static Cottage findCottageById(int id) {// finding the cottage by id number 
        for (Cottage c : cottages) {// go through all the cottages and check them
            if (c != null && c.getId() == id) return c;
        }
        return null;
    }

    
    private static class Candidate {
        Cottage cottage;
        double score;
        Candidate(Cottage c, double s) { cottage = c; score = s; }
    }

    private static Candidate[] getClosestMatches(String wantedType, int partySize, double maxPrice,
                                                boolean wantSeaView, boolean wantPets, int topN) {
        Candidate[] list = new Candidate[cottages.length];
        int count = 0;

        for (Cottage c : cottages) {
            if (c == null) continue;

            double score = 0.0;
            if (c.getType().equalsIgnoreCase(wantedType)) score += 50;
            int diff = Math.abs(partySize - c.getMaxOccupancy());
            score -= diff * 5;
            double priceDiff = c.getPricePerNight() - maxPrice;
            if (priceDiff > 0) score -= priceDiff * 0.2;
            else score += Math.min(10.0, -priceDiff * 0.05);
            score += (c.hasSeaView() == wantSeaView) ? 20 : -10;
            score += (c.isPetsAllowed() == wantPets) ? 20 : -10;
            if (!c.isBooked()) score += 10;

            list[count++] = new Candidate(c, score);
        }

        
        Arrays.sort(list, 0, count, (a, b) -> Double.compare(b.score, a.score));

        int resultSize = Math.min(topN, count);
        Candidate[] best = new Candidate[resultSize];
        for (int i = 0; i < resultSize; i++) best[i] = list[i];
        return best;
    }

    
    private static void findSuitableCottages() {
        System.out.println("FIND A SUITABLE COTTAGE");

        System.out.print("Enter cottage type (Terraced / Detached / Bungalow): ");
        String wantedType = input.nextLine().trim();

        int partySize = readInt("Enter party size (number of people): ");
        double maxPrice = readDouble("Enter maximum price per night: ");
        boolean wantSeaView = readYesNo("Do you want a sea view? (Y/N): ");
        boolean wantPetsAllowed = readYesNo("Do you need pets to be allowed? (Y/N): ");

        boolean foundAny = false;
        System.out.println("\n-- SUITABLE COTTAGES --");
        for (Cottage c : cottages) {
            if (c == null) continue;
            if (!c.getType().equalsIgnoreCase(wantedType)) continue;
            if (partySize > c.getMaxOccupancy()) continue;
            if (c.getPricePerNight() > maxPrice) continue;
            if (c.hasSeaView() != wantSeaView) continue;
            if (c.isPetsAllowed() != wantPetsAllowed) continue;
            System.out.println(c.toString());
            foundAny = true;
        }

        if (!foundAny) {//what is there was 0 matches 
            System.out.println("No cottages match those exact requirements.");// inform the user that there was no exact match
            boolean seeAlternatives = readYesNo("Would you like to see the closest matches instead? (Y/N): ");
            if (seeAlternatives) {
                Candidate[] suggestions = getClosestMatches(wantedType, partySize, maxPrice, wantSeaView, wantPetsAllowed, 3);
                System.out.println("\n-- SUGGESTED ALTERNATIVES --");
                for (int i = 0; i < suggestions.length; i++) {
                    System.out.printf("Option %d (score %.1f): %s%n", i + 1, suggestions[i].score, suggestions[i].cottage.toString());
                }
                System.out.println("\nUse option 3 in the main menu to book any of these by ID.");
            } else {
                System.out.println("Returning to menu.");
            }
        }
    }

    
    private static void makeBooking() throws Exception {

        System.out.println("\n-- MAKE A BOOKING --");//title 
        
        String type = readString("Type (Terraced / Detached / Bungalow): ");// what cottage type is wanted and read their answer 
        int partySize = readInt("Party size: ");// how many people are going to stay in the cottage
        double maxPrice = readDouble("Max price per night: ");
        boolean wantSeaView = readYesNo("Sea view? (Y/N): ");// boolean for Y/N questions 
        boolean wantPets = readYesNo("Pets allowed? (Y/N): ");

        Cottage selected = null;
        // try to find first exact available match
        for (Cottage c : cottages) {
            if (c == null) continue;// skip any empty slots in the array just in case 
            if (!c.isBooked()
                    && c.getType().equalsIgnoreCase(type)// type matches what the user wants 
                    && c.getMaxOccupancy() >= partySize// cottage must fit the number of people the user has entered 
                    && c.getPricePerNight() <= maxPrice
                    && c.hasSeaView() == wantSeaView
                    && c.isPetsAllowed() == wantPets) {
                selected = c;
                break;// stop searching 
            }
        }
     // if no exact match was found, offer closest alternatives
        if (selected == null) {
            System.out.println("No exact match found for your choices.");
            boolean seeAlt = readYesNo("See closest matches? (Y/N): ");
            if (!seeAlt) return;

            Candidate[] best = getClosestMatches(type, partySize, maxPrice, wantSeaView, wantPets, 3);

            System.out.println(" CLOSEST MATCHES");
            for (int i = 0; i < best.length; i++) {
                System.out.printf("%d) %s%n", i + 1, best[i].cottage.toString());
            }

            int pick = readInt("Choose one to book (1-" + best.length + "): ");
            if (pick < 1 || pick > best.length) {
                System.out.println("Invalid choice. Returning to menu.");
                return;
            }

            selected = best[pick - 1].cottage;
        }

     // ask for email to complete reservation 
        String email = readString("Email for the booking (this will be saved): ");
        while (email.isEmpty() || !email.contains("@") || !email.contains(".")) {
            System.out.println("Please enter a valid email (must contain '@' and a domain).");
            email = readString("Email for the booking: ");
        }
        selected.book(email);

        System.out.println(" the Booking is successful!");
        System.out.println(selected.toString());

        // save instantly
        saveCottagesToFile();
        System.out.println("Reservation saved to cottages (2).txt");
    }

    // canceling the booking 
    private static void cancelBooking() {
        System.out.println("\n-- CANCEL A BOOKING --");
        displayCottages();
        int id = readInt("\nEnter cottage id to cancel (just the number please ): ");
        Cottage c = findCottageById(id);
        if (c == null) {
            System.out.println("No cottage with that ID.");// error handling code. 
            return;
        }
        if (!c.isBooked()) {
            System.out.println("That cottage was not booked.");
            return;
        }
        c.cancelBooking();
        try {
            saveCottagesToFile();
            System.out.println("Booking cancelled and saved.");
        } catch (Exception e) {
            System.out.println("Booking cancelled but failed to save file: " + e.getMessage());
        }
    }

    // safe the cottages to the file 
    private static void saveCottagesToFile() throws Exception {
        PrintWriter out = new PrintWriter(new FileWriter("cottages (2).txt"));

        for (int i = 0; i < cottages.length; i++) {
            Cottage c = cottages[i];
            if (c == null) continue;
            out.println(
                    c.getId() + " " +
                    c.getType() + " " +
                    c.getMaxOccupancy() + " " +
                    String.format("%.2f", c.getPricePerNight()) + " " +
                    c.hasSeaView() + " " +
                    c.isPetsAllowed() + " " +
                    (c.isBooked() ? c.getBookedName() : "free")
            );
        }

        out.close();
    }

    // MAIN PROGRAM 
    public static void main(String[] args) throws Exception {

        loadCottages(); // load at start all the cottages 

        String choice;
        System.out.println("Welcome to the Cottage Booking System.");// welcome the user message 

        do {
            System.out.println("\n|MAIN MENU|");
            System.out.println("1 - Display all cottages");
            System.out.println("2 - Display reserved cottages");
            System.out.println("3 - Find suitable cottages");
            System.out.println("4 - Make a booking");
            System.out.println("5 - Cancel a booking");
            System.out.println("Q - Quit");
            System.out.print("Pick: ");

            choice = input.nextLine().trim().toUpperCase();
//read the user input
            switch (choice) {
                case "1":
                    displayCottages();
                    break;
                case "2":
                    displayReservedCottages();
                    break;
                case "3":
                    findSuitableCottages();
                    break;
                case "4":
                    makeBooking();
                    break;
                case "5":
                    cancelBooking();
                    break;
                case "Q":
                    // save on exit 
                    saveCottagesToFile();
                    System.out.println("Thank you for choosing our property!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }

        } while (!choice.equals("Q"));
    }
}