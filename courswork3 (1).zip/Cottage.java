package courswork;// package folder name

public class Cottage {

    private int id;// unique cottage id
    private String type;// type of the cottage 
    private int maxOccupancy;// max number of people the cottage can fit 
    private double pricePerNight;
    private boolean seaView;
    private boolean petsAllowed;

    private boolean booked = false;// is it booked ?
    private String bookedName = "free";// free if not booked 

    
    public Cottage(int id, String type, int maxOccupancy, double pricePerNight,
                   boolean seaView, boolean petsAllowed, String bookedNameFromFile) {

        this.id = id;// assign an id
        this.type = type;// assign a type
        this.maxOccupancy = maxOccupancy;
        this.pricePerNight = pricePerNight;
        this.seaView = seaView;
        this.petsAllowed = petsAllowed;
        // If loaded from file as "free", set booked = false
        if (bookedNameFromFile.equalsIgnoreCase("free")) {
            this.booked = false;
            this.bookedName = "free";
        } else {// otherwise, cottage is already booked
            this.booked = true;
            this.bookedName = bookedNameFromFile;
        }
    }

    // GETTER METHODS (return property values)
    public int getId() { return id; }
    public String getType() { return type; }
    public int getMaxOccupancy() { return maxOccupancy; }
    public double getPricePerNight() { return pricePerNight; }
    public boolean hasSeaView() { return seaView; }
    public boolean isPetsAllowed() { return petsAllowed; }

    
    public boolean isBooked() { return booked; }
    public String getBookedName() { return bookedName; }

    public void book(String name) {
        this.booked = true;
        this.bookedName = name;
    }
    // METHOD to cancel a booking
    public void cancelBooking() {
        this.booked = false;
        this.bookedName = "free";
    }

    
    public String toString() {
        return "Cottage " + id + ": " + type +
                " | sleeps " + maxOccupancy +
                " | £" + pricePerNight + " per night" +
                " | Sea view: " + (seaView ? "Yes" : "No") +
                " | Pets allowed: " + (petsAllowed ? "Yes" : "No") +
                " | Booked: " + (booked ? bookedName : "free");
    }
}
